"""
content_generator.py

Given a syllabus topic, retrieves the most relevant chunks from the indexed
reference material (built by ingest.py) and asks Gemini to generate
structured study notes grounded in that retrieved text.

This is the RAG step: the model is instructed to use ONLY the retrieved
context, which is what keeps the generated notes accurate and reduces
hallucinated facts compared to asking the model to generate from memory.

Run directly to test:
    python content_generator.py
"""

import os
import chromadb
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
genai.configure(api_key=os.environ["GEMINI_API_KEY"])

STORE_DIR = "chroma_store"
COLLECTION_NAME = "study_material"
EMBED_MODEL = "models/text-embedding-004"
GEN_MODEL = "gemini-2.5-flash"
TOP_K = 4  # how many chunks to retrieve per query


def retrieve_context(topic, top_k=TOP_K):
    """Embed the topic and pull the most similar chunks from the vector store."""
    client = chromadb.PersistentClient(path=STORE_DIR)
    collection = client.get_collection(COLLECTION_NAME)

    query_embedding = genai.embed_content(model=EMBED_MODEL, content=topic)["embedding"]
    results = collection.query(query_embeddings=[query_embedding], n_results=top_k)

    chunks = results["documents"][0]
    sources = [meta["source"] for meta in results["metadatas"][0]]
    return chunks, sources


def build_prompt(topic, chunks):
    context = "\n\n---\n\n".join(chunks)
    return f"""You are a study-notes generator for a student preparing for exams.

Using ONLY the reference material below, write clear, structured study notes
on the topic: "{topic}"

Reference material:
{context}

Instructions:
- Include: a short definition, key concepts explained simply, at least one
  example, and any relevant formulas or complexity/rules mentioned in the text.
- If the reference material does not fully cover the topic, say so explicitly
  rather than filling gaps with outside knowledge.
- Use clear headings and bullet points. Keep it exam-focused, not a full essay.
"""


def generate_content(topic):
    chunks, sources = retrieve_context(topic)
    if not chunks:
        return "No reference material found for this topic. Add relevant files to data/ and rerun ingest.py.", []

    prompt = build_prompt(topic, chunks)
    model = genai.GenerativeModel(GEN_MODEL)
    response = model.generate_content(prompt)
    return response.text, sorted(set(sources))


if __name__ == "__main__":
    topic = input("Enter a syllabus topic: ")
    notes, sources = generate_content(topic)
    print("\n" + "=" * 60)
    print(notes)
    print("=" * 60)
    print(f"\nGrounded in: {', '.join(sources)}")
