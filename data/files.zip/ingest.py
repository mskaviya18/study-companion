"""
ingest.py

Reads .txt reference files from the data/ folder, splits them into small
overlapping chunks, embeds each chunk with Gemini's embedding model, and
stores the result in a persistent Chroma collection on disk.

Run this once whenever you add or change files in data/:
    python ingest.py
"""

import os
import glob
import chromadb
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
genai.configure(api_key=os.environ["GEMINI_API_KEY"])

DATA_DIR = "data"
STORE_DIR = "chroma_store"
COLLECTION_NAME = "study_material"
CHUNK_SIZE = 800       # characters per chunk
CHUNK_OVERLAP = 150    # overlap between consecutive chunks
EMBED_MODEL = "models/text-embedding-004"


def chunk_text(text, chunk_size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    """Split text into overlapping chunks so context isn't lost at boundaries."""
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end].strip())
        start += chunk_size - overlap
    return [c for c in chunks if c]


def embed_texts(texts):
    """Embed a list of texts using Gemini's embedding model, one call per text."""
    embeddings = []
    for text in texts:
        result = genai.embed_content(model=EMBED_MODEL, content=text)
        embeddings.append(result["embedding"])
    return embeddings


def main():
    client = chromadb.PersistentClient(path=STORE_DIR)
    # Start fresh each run so re-ingesting doesn't create duplicate chunks
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass
    collection = client.create_collection(COLLECTION_NAME)

    txt_files = glob.glob(os.path.join(DATA_DIR, "*.txt"))
    if not txt_files:
        print(f"No .txt files found in {DATA_DIR}/. Add reference material and rerun.")
        return

    all_chunks, all_ids, all_metadatas = [], [], []
    for file_path in txt_files:
        source_name = os.path.basename(file_path)
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()
        chunks = chunk_text(text)
        for i, chunk in enumerate(chunks):
            all_chunks.append(chunk)
            all_ids.append(f"{source_name}_{i}")
            all_metadatas.append({"source": source_name})
        print(f"{source_name}: {len(chunks)} chunks")

    print(f"Embedding {len(all_chunks)} chunks total (this calls the API once per chunk)...")
    embeddings = embed_texts(all_chunks)

    collection.add(
        ids=all_ids,
        embeddings=embeddings,
        documents=all_chunks,
        metadatas=all_metadatas,
    )
    print(f"Done. Indexed {len(all_chunks)} chunks into '{COLLECTION_NAME}' at {STORE_DIR}/")


if __name__ == "__main__":
    main()
